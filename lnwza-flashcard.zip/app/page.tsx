"use client"

import Image from "next/image";

export default function Home() {
  const handleOnGetSheetDataClick = async () => {
      const response = await fetch('/api/', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      console.log(data);
  };

  return (
    <>
      <button onClick={handleOnGetSheetDataClick} className=" text-black text-2xl">Get Sheet Data</button>
    </>
  ) 
}
